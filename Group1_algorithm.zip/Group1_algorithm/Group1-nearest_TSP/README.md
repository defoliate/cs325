CS325-Group1-nearest-TSP
Group member: Qingxiao Yuan,Jingyu xiang,Peng Jui Huang.

Compile:
Type 'make' into terminal. Then type './TSP [filename]' to run. 

e.g. 
1. type "./TSP tsp_test_cases/test-input-1.txt",
2. the output file "test-input-1.txt.tour" will under the directory "tsp_test_cases". Meanwhile, the best result will be shown in the console:
	"Total Cost: 5582
 	 Time: 2 ms".
