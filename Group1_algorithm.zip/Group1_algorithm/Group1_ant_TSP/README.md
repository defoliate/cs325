CS325-Group1-ant-TSP
Group member: Qingxiao Yuan,Jingyu xiang,Peng Jui Huang.


# ant-colony-tsp
Solve TSP using Ant Colony Optimization in Python 3

### Requirements
* Python3
* matplotlib

### Compile
Run `python3 main.py` to see the results.
inputflie:xxxxxx.txt
